const colors = {
    red:'red',
    black:'black',
    white:'white',
    green:'green',
    blue:'blue',
    steelBlue: 'steelblue',
    lightGreen:'#98FB98',
    lightBlue:'lightblue',
    lightPink:'lightpink',
    grey:'grey'
}

export default colors;