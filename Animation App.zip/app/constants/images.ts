const images ={
    background:require('../assets/backgroundImage.jpg'),
    backIcon:require('../assets/back.png')
}

export default images;