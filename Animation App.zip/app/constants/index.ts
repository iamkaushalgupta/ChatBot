import colors from "./color";
import images from "./images";
import strings from "./string";


export {colors,images,strings};