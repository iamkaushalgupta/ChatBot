const strings  = {
    springAnimation:'Spring Animation',
    timingAnimation:'Timing Animation',
    decayAnimation:'Decay Animation',
    eventAnimation:'Event Animation',
    interpolationAnimation:'Interpolation Animation',
    loopInAnimation:'Loop in Animation',
    ParallelAnimation: 'Parallel Animation',
    sequenceAnimation:'Sequence Animation',
    staggerAnimation:'Stagger Animation',   
    fadeInFadeOutAnimation:'Fade In Fade Out',
    successiveTechnologies:'Successive Technologies',
    fadingView:'Fading View!',
    clickMe:'Click me',
    fadeInButton:'Fade In Button',
    fadeOutButton:'Fade Out Button',
    ReactAnimations:'React Animation'
}
export default strings